package ece325;

/**
 * Assignment 5: Interfaces <br />
 * Part 3: The {@code Person} class
 */
public class Person {
    int age; // The age of the person

    public Person(int age) {
        this.age = age;
    }
}
